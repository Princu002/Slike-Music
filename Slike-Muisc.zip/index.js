import { execSync } from "child_process";

execSync("npx tsc");
